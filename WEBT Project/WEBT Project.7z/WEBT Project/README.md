# IF.03.01-06 Basic Web Techniques - Information Website
This coding assignment shall make you practice all concepts we have learned so far. Make sure that you read the section *Required Tasks*  in [CodingAssignment.md](CodingAssignment.md) carefully and to complete all the tasks listed there.
